#ifndef rrArrayListItemBaseH
#define rrArrayListItemBaseH
//---------------------------------------------------------------------------
#include "rrc_exporter.h"

namespace rrc
{

    /** @cond PRIVATE
     * a proprietaty collection class that is theoretically deprecated, but used extensively in rrc_api.cpp
     */
    class C_DECL_SPEC ArrayListItemBase
    {
    public:
        virtual ~ArrayListItemBase();
    };
    /** @endcond PRIVATE */


}
#endif
